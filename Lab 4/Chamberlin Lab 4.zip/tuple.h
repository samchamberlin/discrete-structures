#ifndef TUPLE_H
#define TUPLE_H

class Tuple : public vector<string>{

};

#endif
