#ifndef SCHEME_H
#define SCHEME_H

class Scheme : public vector<string>{

};

#endif
